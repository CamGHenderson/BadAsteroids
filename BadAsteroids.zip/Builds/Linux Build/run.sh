#!/bin/sh

./Application
